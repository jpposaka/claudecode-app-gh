import React, { useState, useEffect } from 'react';
import { User, Home, Pill, Settings, Plus, Search, Edit, Eye, AlertTriangle, Camera, FileText, MessageSquare, ClipboardList, Users, Calendar, Download, Clock, DollarSign, Utensils, ChevronLeft, ChevronRight } from 'lucide-react';

// Mock data
const mockResidents = [
  {
    id: 1,
    name: '田中 花子',
    age: 78,
    gender: '女性',
    careLevel: '区分2',
    allergies: '卵アレルギー',
    photoUrl: null,
    facility: '鮎川',
    benefitCard: {
      expiryDate: '2025-08-15',
      daysUntilExpiry: 38
    },
    lastVitals: {
      temperature: 36.5,
      bloodPressure: '120/80',
      pulse: 72,
      date: '2025-07-08 09:00'
    }
  },
  {
    id: 2,
    name: '佐藤 太郎',
    age: 82,
    gender: '男性',
    careLevel: '区分3',
    allergies: 'なし',
    photoUrl: null,
    facility: '並木',
    benefitCard: {
      expiryDate: '2025-07-25',
      daysUntilExpiry: 17
    },
    lastVitals: {
      temperature: 37.2,
      bloodPressure: '140/90',
      pulse: 85,
      date: '2025-07-08 08:30'
    }
  },
  {
    id: 3,
    name: '鈴木 美和',
    age: 75,
    gender: '女性',
    careLevel: '区分1',
    allergies: 'なし',
    photoUrl: null,
    facility: '末広',
    benefitCard: {
      expiryDate: '2025-09-10',
      daysUntilExpiry: 64
    },
    lastVitals: {
      temperature: 36.3,
      bloodPressure: '110/70',
      pulse: 68,
      date: '2025-07-08 09:15'
    }
  },
  {
    id: 4,
    name: '山田 次郎',
    age: 79,
    gender: '男性',
    careLevel: '区分4',
    allergies: '薬物アレルギー',
    photoUrl: null,
    facility: '大同',
    benefitCard: {
      expiryDate: '2025-11-20',
      daysUntilExpiry: 135
    },
    lastVitals: {
      temperature: 36.8,
      bloodPressure: '130/85',
      pulse: 75,
      date: '2025-07-08 08:45'
    }
  },
  {
    id: 5,
    name: '高橋 恵子',
    age: 85,
    gender: '女性',
    careLevel: '区分5',
    allergies: 'なし',
    photoUrl: null,
    facility: '津之江',
    benefitCard: {
      expiryDate: '2025-12-31',
      daysUntilExpiry: 176
    },
    lastVitals: {
      temperature: 36.6,
      bloodPressure: '125/80',
      pulse: 70,
      date: '2025-07-08 09:30'
    }
  },
  {
    id: 6,
    name: '渡辺 信夫',
    age: 77,
    gender: '男性',
    careLevel: '区分2',
    allergies: 'なし',
    photoUrl: null,
    facility: '寿町',
    benefitCard: {
      expiryDate: '2025-10-15',
      daysUntilExpiry: 99
    },
    lastVitals: {
      temperature: 36.4,
      bloodPressure: '115/75',
      pulse: 72,
      date: '2025-07-08 08:00'
    }
  },
  {
    id: 7,
    name: '木村 静香',
    age: 81,
    gender: '女性',
    careLevel: '区分3',
    allergies: '食物アレルギー',
    photoUrl: null,
    facility: '古曽部',
    benefitCard: {
      expiryDate: '2025-08-30',
      daysUntilExpiry: 53
    },
    lastVitals: {
      temperature: 36.7,
      bloodPressure: '120/78',
      pulse: 74,
      date: '2025-07-08 09:00'
    }
  },
  {
    id: 8,
    name: '小林 健一',
    age: 76,
    gender: '男性',
    careLevel: '区分1',
    allergies: 'なし',
    photoUrl: null,
    facility: '鮎川',
    benefitCard: {
      expiryDate: '2025-07-20',
      daysUntilExpiry: 12
    },
    lastVitals: {
      temperature: 36.2,
      bloodPressure: '108/68',
      pulse: 66,
      date: '2025-07-08 08:30'
    }
  },
  {
    id: 9,
    name: '松本 かおる',
    age: 83,
    gender: '女性',
    careLevel: '区分6',
    allergies: 'なし',
    photoUrl: null,
    facility: '並木',
    benefitCard: {
      expiryDate: '2025-09-05',
      daysUntilExpiry: 59
    },
    lastVitals: {
      temperature: 36.9,
      bloodPressure: '135/88',
      pulse: 78,
      date: '2025-07-08 09:15'
    }
  },
  {
    id: 10,
    name: '中村 豊',
    age: 80,
    gender: '男性',
    careLevel: '区分4',
    allergies: 'なし',
    photoUrl: null,
    facility: '末広',
    benefitCard: {
      expiryDate: '2025-11-10',
      daysUntilExpiry: 125
    },
    lastVitals: {
      temperature: 36.5,
      bloodPressure: '122/76',
      pulse: 71,
      date: '2025-07-08 08:45'
    }
  },
  {
    id: 11,
    name: '伊藤 正美',
    age: 74,
    gender: '女性',
    careLevel: '区分2',
    allergies: 'なし',
    photoUrl: null,
    facility: '大同',
    benefitCard: {
      expiryDate: '2025-10-25',
      daysUntilExpiry: 109
    },
    lastVitals: {
      temperature: 36.4,
      bloodPressure: '118/74',
      pulse: 69,
      date: '2025-07-08 09:00'
    }
  },
  {
    id: 12,
    name: '加藤 清',
    age: 78,
    gender: '男性',
    careLevel: '区分3',
    allergies: 'なし',
    photoUrl: null,
    facility: '津之江',
    benefitCard: {
      expiryDate: '2025-12-15',
      daysUntilExpiry: 160
    },
    lastVitals: {
      temperature: 36.6,
      bloodPressure: '126/82',
      pulse: 73,
      date: '2025-07-08 08:15'
    }
  }
];

const mockNotes = [
  {
    id: 1,
    residentId: 1,
    content: '朝食を半分程度摂取。食欲がいつもより少ない様子。',
    author: '鮎川',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 09:30',
    tags: ['食事'],
    imageUrl: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=300&h=200&fit=crop',
    memo: '好きなおかずを声かけで提供し、水分補給も意識してください',
    supportType: 'day' // 日中支援
  },
  {
    id: 2,
    residentId: 2,
    content: '今朝から風邪気味で、いつもより元気がない状態。',
    author: '並木',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 08:45',
    tags: ['バイタル', '体調'],
    imageUrl: null,
    memo: '気持ちが下がっているので元気な言葉がけをお願いします。室温調整も注意',
    supportType: 'day' // 日中支援
  },
  {
    id: 3,
    residentId: 1,
    content: 'リハビリで立位保持が5秒間できました。',
    author: '理学療法士 佐々木',
    authorType: 'dayservice',
    facility: 'ぽぽらす（通所先）',
    timestamp: '2025-07-07 14:20',
    tags: ['リハビリ'],
    imageUrl: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=200&fit=crop',
    memo: '継続的な改善が見られるので、今後も励ましの声かけを続けてください',
    supportType: 'day' // 日中支援
  },
  {
    id: 4,
    residentId: 3,
    content: '夜間よく眠れていない様子で、日中うとうとされていました。',
    author: '末広',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-07 15:30',
    tags: ['睡眠', '様子'],
    imageUrl: null,
    memo: '日中の活動量を少し増やし、夕方以降はカフェイン控えめでお願いします',
    supportType: 'day' // 日中支援
  },
  {
    id: 5,
    residentId: 4,
    content: '薬の服用を嫌がられ、説明に時間がかかりました。',
    author: '大同',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 07:30',
    tags: ['服薬', '拒否'],
    imageUrl: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=300&h=200&fit=crop',
    memo: '○○さんの好きな飲み物と一緒に服薬介助すると受け入れやすいです',
    supportType: 'day' // 日中支援
  },
  {
    id: 6,
    residentId: 5,
    content: '本日は笑顔が多く、レクリエーションにも積極的に参加されました。',
    author: '生活支援員 橋本',
    authorType: 'dayservice',
    facility: 'ぽぽらす（通所先）',
    timestamp: '2025-07-07 13:00',
    tags: ['レクリエーション'],
    imageUrl: 'https://images.unsplash.com/photo-1581579438747-1dc8d17bbce4?w=300&h=200&fit=crop',
    memo: '調子が良い日なので、今日は会話を多めにしていただけると喜ばれます',
    supportType: 'day' // 日中支援
  },
  {
    id: 7,
    residentId: 6,
    content: '便秘が3日続いているため、水分摂取量を増やしています。',
    author: '寿町',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 06:00',
    tags: ['排泄', '水分'],
    imageUrl: null,
    memo: '食事時以外でも定期的に水分提供をお願いします。軽い運動も効果的です',
    supportType: 'day' // 日中支援
  },
  {
    id: 8,
    residentId: 7,
    content: '家族からのお手紙を読んで、とても喜ばれていました。',
    author: '古曽部',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-07 16:00',
    tags: ['面会', '家族'],
    imageUrl: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=300&h=200&fit=crop',
    memo: '家族の話をされた時は、しっかりと聞いて共感してあげてください',
    supportType: 'day' // 日中支援
  },
  {
    id: 9,
    residentId: 1,
    content: '夜間巡回時、安眠されている様子でした。',
    author: '夜勤スタッフ 田村',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 02:00',
    tags: ['夜間巡回', '睡眠'],
    imageUrl: null,
    memo: '室温は適切でした。朝食時の様子を確認してください',
    supportType: 'night' // 夜間巡回
  },
  {
    id: 10,
    residentId: 2,
    content: '夜間2回トイレに起きられました。転倒なく自立されています。',
    author: '夜勤スタッフ 田村',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-08 01:30',
    tags: ['夜間巡回', '排泄'],
    imageUrl: null,
    memo: '見守りは継続してください',
    supportType: 'night' // 夜間巡回
  },
  {
    id: 11,
    residentId: 3,
    content: '夜間巡回時、寝返りをうたれていました。特に変わりありません。',
    author: '夜勤スタッフ 佐藤',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-07 23:30',
    tags: ['夜間巡回'],
    imageUrl: null,
    memo: '',
    supportType: 'night' // 夜間巡回
  },
  {
    id: 12,
    residentId: 4,
    content: '夜間巡回時、深い眠りについておられました。',
    author: '夜勤スタッフ 佐藤',
    authorType: 'facility',
    facility: 'たぬきのお家（グループホーム）',
    timestamp: '2025-07-07 22:45',
    tags: ['夜間巡回', '睡眠'],
    imageUrl: null,
    memo: '朝の起床時間は通常通りでお願いします',
    supportType: 'night' // 夜間巡回
  }
];

const mockMedications = [
  {
    id: 1,
    residentId: 1,
    drugName: 'アムロジピン錠5mg',
    remaining: 12,
    threshold: 7,
    lastChecked: '2025-07-07',
    prescriptionImage: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=300&h=200&fit=crop',
    prescriptionEndDate: '2025-07-20',
    dosage: '1日1回 朝食後',
    prescribedBy: '田中内科クリニック'
  },
  {
    id: 2,
    residentId: 2,
    drugName: 'メトホルミン錠250mg',
    remaining: 8,
    threshold: 7,
    lastChecked: '2025-07-08',
    prescriptionImage: null,
    prescriptionEndDate: '2025-07-15',
    dosage: '1日3回 毎食後',
    prescribedBy: '山田病院'
  }
];

const mockContactBook = [
  {
    id: 1,
    title: '7月の行事予定について',
    content: '来週予定している夏祭りの準備について、各利用者の参加可否を確認してください。',
    author: '鮎川',
    timestamp: '2025-07-08 09:00',
    imageUrl: 'https://images.unsplash.com/photo-1534190239940-9ba8944ea261?w=300&h=200&fit=crop',
    isRead: false,
    priority: 'high'
  },
  {
    id: 2,
    title: '利用者の健康管理について',
    content: '最近の気温上昇に伴い、利用者の水分補給に十分注意してください。',
    author: '並木',
    timestamp: '2025-07-07 15:30',
    imageUrl: null,
    isRead: true,
    priority: 'medium'
  },
  {
    id: 3,
    title: '新しい職員の研修について',
    content: '来月から新しい職員が配属されます。研修スケジュールを確認してください。',
    author: '末広',
    timestamp: '2025-07-06 14:00',
    imageUrl: null,
    isRead: false,
    priority: 'medium'
  },
  {
    id: 4,
    title: '備品の発注について',
    content: '介護用品の在庫が少なくなっています。至急発注をお願いします。',
    author: '大同',
    timestamp: '2025-07-05 11:30',
    imageUrl: null,
    isRead: true,
    priority: 'high'
  },
  {
    id: 5,
    title: '避難訓練の実施',
    content: '今月の避難訓練を15日に実施します。各利用者の参加準備をお願いします。',
    author: '津之江',
    timestamp: '2025-07-04 16:45',
    imageUrl: null,
    isRead: true,
    priority: 'medium'
  },
  {
    id: 6,
    title: '面会時間の変更',
    content: '7月から面会時間が変更になります。家族への連絡をお願いします。',
    author: '寿町',
    timestamp: '2025-07-03 10:15',
    imageUrl: null,
    isRead: false,
    priority: 'medium'
  }
];

const mockSupportPlans = [
  {
    id: 1,
    residentId: 1,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-04-01',
    fileUrl: 'support-plan-1.pdf',
    nextReviewDate: '2025-10-01'
  },
  {
    id: 2,
    residentId: 2,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-04-15',
    fileUrl: 'support-plan-2.pdf',
    nextReviewDate: '2025-10-15'
  },
  {
    id: 3,
    residentId: 3,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-05-01',
    fileUrl: 'support-plan-3.pdf',
    nextReviewDate: '2025-11-01'
  },
  {
    id: 4,
    residentId: 4,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-05-10',
    fileUrl: 'support-plan-4.pdf',
    nextReviewDate: '2025-11-10'
  },
  {
    id: 5,
    residentId: 5,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-06-01',
    fileUrl: 'support-plan-5.pdf',
    nextReviewDate: '2025-12-01'
  },
  {
    id: 6,
    residentId: 6,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-06-15',
    fileUrl: 'support-plan-6.pdf',
    nextReviewDate: '2025-12-15'
  },
  {
    id: 7,
    residentId: 7,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-03-20',
    fileUrl: 'support-plan-7.pdf',
    nextReviewDate: '2025-09-20'
  },
  {
    id: 8,
    residentId: 8,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-04-10',
    fileUrl: 'support-plan-8.pdf',
    nextReviewDate: '2025-10-10'
  },
  {
    id: 9,
    residentId: 9,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-05-20',
    fileUrl: 'support-plan-9.pdf',
    nextReviewDate: '2025-11-20'
  },
  {
    id: 10,
    residentId: 10,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-06-05',
    fileUrl: 'support-plan-10.pdf',
    nextReviewDate: '2025-12-05'
  },
  {
    id: 11,
    residentId: 11,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-03-15',
    fileUrl: 'support-plan-11.pdf',
    nextReviewDate: '2025-09-15'
  },
  {
    id: 12,
    residentId: 12,
    title: '個別支援計画書（令和7年度）',
    uploadDate: '2025-04-25',
    fileUrl: 'support-plan-12.pdf',
    nextReviewDate: '2025-10-25'
  }
];

const mockMonitoring = [
  {
    id: 1,
    residentId: 1,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-30',
    fileUrl: 'monitoring-1.pdf',
    achievements: '歩行訓練で目標歩数を達成',
    nextGoals: '立位保持時間の延長'
  },
  {
    id: 2,
    residentId: 2,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-28',
    fileUrl: 'monitoring-2.pdf',
    achievements: '服薬自立度の向上',
    nextGoals: 'コミュニケーション能力向上'
  },
  {
    id: 3,
    residentId: 3,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-25',
    fileUrl: 'monitoring-3.pdf',
    achievements: '食事摂取量の改善',
    nextGoals: '体重増加の継続'
  },
  {
    id: 4,
    residentId: 4,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-20',
    fileUrl: 'monitoring-4.pdf',
    achievements: '睡眠リズムの安定化',
    nextGoals: '日中活動の充実'
  },
  {
    id: 5,
    residentId: 5,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-15',
    fileUrl: 'monitoring-5.pdf',
    achievements: 'レクリエーション参加率向上',
    nextGoals: '他利用者との交流促進'
  },
  {
    id: 6,
    residentId: 1,
    title: '年度中間モニタリング報告書',
    reportDate: '2025-03-31',
    fileUrl: 'monitoring-6.pdf',
    achievements: 'ADL全般の改善',
    nextGoals: '自立支援の継続'
  },
  {
    id: 7,
    residentId: 6,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-10',
    fileUrl: 'monitoring-7.pdf',
    achievements: '排泄自立の達成',
    nextGoals: '移動支援の軽減'
  },
  {
    id: 8,
    residentId: 7,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-06-05',
    fileUrl: 'monitoring-8.pdf',
    achievements: '認知機能の維持',
    nextGoals: '見当識の向上'
  },
  {
    id: 9,
    residentId: 8,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-05-30',
    fileUrl: 'monitoring-9.pdf',
    achievements: '血圧管理の安定',
    nextGoals: '運動療法の継続'
  },
  {
    id: 10,
    residentId: 9,
    title: '第1四半期モニタリング報告書',
    reportDate: '2025-05-25',
    fileUrl: 'monitoring-10.pdf',
    achievements: '家族との関係改善',
    nextGoals: '面会頻度の増加'
  }
];

const mockMeetingMinutes = [
  {
    id: 1,
    residentId: 1,
    title: '第2回支援会議',
    meetingDate: '2025-07-01',
    participants: '医師、看護師、介護士、本人、家族',
    fileUrl: 'meeting-minutes-1.pdf',
    summary: '支援計画の見直しと今後の方針について議論'
  },
  {
    id: 2,
    residentId: 1,
    title: '第1回支援会議',
    meetingDate: '2025-06-15',
    participants: '医師、看護師、介護士、栄養士、家族',
    fileUrl: 'meeting-minutes-2.pdf',
    summary: '田中様の栄養管理と食事支援について検討'
  },
  {
    id: 3,
    residentId: 2,
    title: 'ケアプラン会議（佐藤様）',
    meetingDate: '2025-06-10',
    participants: 'ケアマネ、看護師、介護士、家族',
    fileUrl: 'meeting-minutes-3.pdf',
    summary: 'リハビリ計画の進捗確認と調整'
  },
  {
    id: 4,
    residentId: 2,
    title: '医療連携会議',
    meetingDate: '2025-06-05',
    participants: '主治医、看護師、薬剤師、介護士',
    fileUrl: 'meeting-minutes-4.pdf',
    summary: '服薬管理と医療連携体制の強化'
  },
  {
    id: 5,
    residentId: 3,
    title: '家族面談（鈴木様）',
    meetingDate: '2025-05-30',
    participants: '家族、ケアマネ、施設長、担当介護士',
    fileUrl: 'meeting-minutes-5.pdf',
    summary: '今後の支援方針と家族の要望について'
  },
  {
    id: 6,
    residentId: 4,
    title: '多職種連携会議',
    meetingDate: '2025-05-25',
    participants: '医師、看護師、栄養士、介護士、相談員',
    fileUrl: 'meeting-minutes-6.pdf',
    summary: '利用者全般の健康管理について'
  },
  {
    id: 7,
    residentId: 4,
    title: 'サービス担当者会議（山田様）',
    meetingDate: '2025-05-20',
    participants: 'ケアマネ、ヘルパー、看護師、家族',
    fileUrl: 'meeting-minutes-7.pdf',
    summary: '在宅支援サービスの調整'
  },
  {
    id: 8,
    residentId: 5,
    title: '第3回支援会議',
    meetingDate: '2025-05-15',
    participants: '医師、看護師、介護士、作業療法士',
    fileUrl: 'meeting-minutes-8.pdf',
    summary: 'リハビリテーション計画の評価'
  },
  {
    id: 9,
    residentId: 6,
    title: '緊急ケア会議',
    meetingDate: '2025-05-10',
    participants: '医師、看護師、介護士、家族',
    fileUrl: 'meeting-minutes-9.pdf',
    summary: '急変時対応マニュアルの見直し'
  },
  {
    id: 10,
    residentId: 1,
    title: '年度初回支援会議',
    meetingDate: '2025-04-30',
    participants: '医師、看護師、介護士、栄養士、相談員',
    fileUrl: 'meeting-minutes-10.pdf',
    summary: '新年度の支援方針と目標設定'
  },
  {
    id: 11,
    residentId: 7,
    title: '定期支援会議（木村様）',
    meetingDate: '2025-06-20',
    participants: 'ケアマネ、看護師、介護士、本人、家族',
    fileUrl: 'meeting-minutes-11.pdf',
    summary: '食物アレルギー対応と栄養管理について検討'
  },
  {
    id: 12,
    residentId: 7,
    title: '初回支援会議（木村様）',
    meetingDate: '2025-04-15',
    participants: '医師、看護師、介護士、栄養士、家族',
    fileUrl: 'meeting-minutes-12.pdf',
    summary: '入所時の状態評価と初期支援計画の策定'
  },
  {
    id: 13,
    residentId: 8,
    title: '支援方針検討会議（小林様）',
    meetingDate: '2025-06-25',
    participants: 'ケアマネ、看護師、介護士、理学療法士',
    fileUrl: 'meeting-minutes-13.pdf',
    summary: '血圧管理と運動療法の計画立案'
  },
  {
    id: 14,
    residentId: 8,
    title: '第1回支援会議（小林様）',
    meetingDate: '2025-05-05',
    participants: '医師、看護師、介護士、家族',
    fileUrl: 'meeting-minutes-14.pdf',
    summary: '初期アセスメントと支援目標の設定'
  },
  {
    id: 15,
    residentId: 9,
    title: 'ケアプラン評価会議（松本様）',
    meetingDate: '2025-06-30',
    participants: 'ケアマネ、医師、看護師、介護士、家族',
    fileUrl: 'meeting-minutes-15.pdf',
    summary: '要介護度6の支援体制強化について'
  },
  {
    id: 16,
    residentId: 9,
    title: '医療ケア会議（松本様）',
    meetingDate: '2025-05-22',
    participants: '主治医、看護師、薬剤師、介護士',
    fileUrl: 'meeting-minutes-16.pdf',
    summary: '医療的ケアの必要性と体制整備'
  },
  {
    id: 17,
    residentId: 10,
    title: '第2回支援会議（中村様）',
    meetingDate: '2025-07-02',
    participants: 'ケアマネ、看護師、介護士、作業療法士、家族',
    fileUrl: 'meeting-minutes-17.pdf',
    summary: '日常生活動作の改善と自立支援について'
  },
  {
    id: 18,
    residentId: 10,
    title: '初期評価会議（中村様）',
    meetingDate: '2025-04-20',
    participants: '医師、看護師、介護士、相談員',
    fileUrl: 'meeting-minutes-18.pdf',
    summary: '入所時評価と支援計画の作成'
  },
  {
    id: 19,
    residentId: 11,
    title: '定期支援会議（伊藤様）',
    meetingDate: '2025-06-12',
    participants: 'ケアマネ、看護師、介護士、栄養士',
    fileUrl: 'meeting-minutes-19.pdf',
    summary: '栄養状態の改善と活動量増加の検討'
  },
  {
    id: 20,
    residentId: 11,
    title: '初回アセスメント会議（伊藤様）',
    meetingDate: '2025-04-08',
    participants: '医師、看護師、介護士、家族',
    fileUrl: 'meeting-minutes-20.pdf',
    summary: '初期状態の評価と支援方針の決定'
  },
  {
    id: 21,
    residentId: 12,
    title: '多職種連携会議（加藤様）',
    meetingDate: '2025-07-05',
    participants: '医師、看護師、介護士、理学療法士、家族',
    fileUrl: 'meeting-minutes-21.pdf',
    summary: '転倒予防と歩行訓練プログラムの検討'
  },
  {
    id: 22,
    residentId: 12,
    title: '支援計画策定会議（加藤様）',
    meetingDate: '2025-05-18',
    participants: 'ケアマネ、看護師、介護士、相談員',
    fileUrl: 'meeting-minutes-22.pdf',
    summary: '個別支援計画の策定と役割分担'
  },
  {
    id: 23,
    residentId: 3,
    title: '第2回支援会議（鈴木様）',
    meetingDate: '2025-07-03',
    participants: '医師、看護師、介護士、作業療法士、家族',
    fileUrl: 'meeting-minutes-23.pdf',
    summary: '認知機能維持のための活動プログラム検討'
  },
  {
    id: 24,
    residentId: 5,
    title: '家族合同会議（高橋様）',
    meetingDate: '2025-06-28',
    participants: '家族、ケアマネ、施設長、看護師、介護士',
    fileUrl: 'meeting-minutes-24.pdf',
    summary: '終末期ケアの方針と家族の意向確認'
  },
  {
    id: 25,
    residentId: 6,
    title: '第2回定期会議（渡辺様）',
    meetingDate: '2025-06-18',
    participants: 'ケアマネ、看護師、介護士、栄養士',
    fileUrl: 'meeting-minutes-25.pdf',
    summary: '便秘改善のための生活習慣指導について'
  }
];

const mockVitalRecords = [
  {
    id: 1,
    residentId: 1,
    date: '2025-07-08',
    time: '09:00',
    temperature: 36.5,
    bloodPressureSys: 120,
    bloodPressureDia: 80,
    pulse: 72,
    memo: '体調良好'
  },
  {
    id: 2,
    residentId: 1,
    date: '2025-07-07',
    time: '09:00',
    temperature: 36.3,
    bloodPressureSys: 118,
    bloodPressureDia: 78,
    pulse: 70,
    memo: ''
  },
  {
    id: 3,
    residentId: 2,
    date: '2025-07-08',
    time: '08:30',
    temperature: 37.2,
    bloodPressureSys: 140,
    bloodPressureDia: 90,
    pulse: 85,
    memo: '微熱あり'
  }
];

const mockBenefitCards = [
  {
    id: 1,
    residentId: 1,
    serviceType: 'グループホーム',
    startDate: '2024-08-15',
    endDate: '2025-08-15',
    monthlyHours: 744,
    daysUntilExpiry: 38
  },
  {
    id: 2,
    residentId: 1,
    serviceType: '福祉作業',
    startDate: '2024-08-15', 
    endDate: '2025-08-15',
    monthlyHours: 120,
    daysUntilExpiry: 38
  },
  {
    id: 3,
    residentId: 2,
    serviceType: 'グループホーム',
    startDate: '2024-07-25',
    endDate: '2025-07-25',
    monthlyHours: 744,
    daysUntilExpiry: 17
  },
  {
    id: 4,
    residentId: 3,
    serviceType: 'グループホーム',
    startDate: '2024-09-10',
    endDate: '2025-09-10',
    monthlyHours: 744,
    daysUntilExpiry: 64
  },
  {
    id: 5,
    residentId: 3,
    serviceType: '移動支援',
    startDate: '2024-09-10',
    endDate: '2025-09-10',
    monthlyHours: 50,
    daysUntilExpiry: 64
  },
  {
    id: 6,
    residentId: 4,
    serviceType: 'グループホーム',
    startDate: '2024-11-20',
    endDate: '2025-11-20',
    monthlyHours: 744,
    daysUntilExpiry: 135
  },
  {
    id: 7,
    residentId: 5,
    serviceType: 'グループホーム',
    startDate: '2024-12-31',
    endDate: '2025-12-31',
    monthlyHours: 744,
    daysUntilExpiry: 176
  },
  {
    id: 8,
    residentId: 5,
    serviceType: '福祉作業',
    startDate: '2024-12-31',
    endDate: '2025-12-31',
    monthlyHours: 100,
    daysUntilExpiry: 176
  },
  {
    id: 9,
    residentId: 6,
    serviceType: 'グループホーム',
    startDate: '2024-10-15',
    endDate: '2025-10-15',
    monthlyHours: 744,
    daysUntilExpiry: 99
  },
  {
    id: 10,
    residentId: 7,
    serviceType: 'グループホーム',
    startDate: '2024-08-30',
    endDate: '2025-08-30',
    monthlyHours: 744,
    daysUntilExpiry: 53
  },
  {
    id: 11,
    residentId: 7,
    serviceType: '移動支援',
    startDate: '2024-08-30',
    endDate: '2025-08-30',
    monthlyHours: 40,
    daysUntilExpiry: 53
  },
  {
    id: 12,
    residentId: 8,
    serviceType: 'グループホーム',
    startDate: '2024-07-20',
    endDate: '2025-07-20',
    monthlyHours: 744,
    daysUntilExpiry: 12
  },
  {
    id: 13,
    residentId: 9,
    serviceType: 'グループホーム',
    startDate: '2024-09-05',
    endDate: '2025-09-05',
    monthlyHours: 744,
    daysUntilExpiry: 59
  },
  {
    id: 14,
    residentId: 9,
    serviceType: '福祉作業',
    startDate: '2024-09-05',
    endDate: '2025-09-05',
    monthlyHours: 160,
    daysUntilExpiry: 59
  },
  {
    id: 15,
    residentId: 10,
    serviceType: 'グループホーム',
    startDate: '2024-11-10',
    endDate: '2025-11-10',
    monthlyHours: 744,
    daysUntilExpiry: 125
  },
  {
    id: 16,
    residentId: 11,
    serviceType: 'グループホーム',
    startDate: '2024-10-25',
    endDate: '2025-10-25',
    monthlyHours: 744,
    daysUntilExpiry: 109
  },
  {
    id: 17,
    residentId: 11,
    serviceType: '移動支援',
    startDate: '2024-10-25',
    endDate: '2025-10-25',
    monthlyHours: 30,
    daysUntilExpiry: 109
  },
  {
    id: 18,
    residentId: 12,
    serviceType: 'グループホーム',
    startDate: '2024-12-15',
    endDate: '2025-12-15',
    monthlyHours: 744,
    daysUntilExpiry: 160
  }
];

const mockEvents = [
  {
    id: 1,
    residentId: 1,
    title: '通院（内科）',
    date: '2025-07-08',
    time: '14:00',
    category: 'medical',
    note: '定期健診'
  },
  {
    id: 2,
    residentId: 2,
    title: 'リハビリ',
    date: '2025-07-08',
    time: '15:30',
    category: 'rehabilitation',
    note: '理学療法'
  },
  {
    id: 3,
    residentId: 1,
    title: '家族面会',
    date: '2025-07-10',
    time: '13:00',
    category: 'visit',
    note: '娘さん来訪予定'
  },
  {
    id: 4,
    residentId: 2,
    title: '通院（眼科）',
    date: '2025-07-12',
    time: '10:00',
    category: 'medical',
    note: '白内障検査'
  },
  {
    id: 5,
    residentId: 1,
    title: 'デイサービス',
    date: '2025-07-15',
    time: '09:00',
    category: 'dayservice',
    note: '送迎あり'
  },
  {
    id: 6,
    residentId: 2,
    title: '外出（散歩）',
    date: '2025-07-16',
    time: '10:30',
    category: 'outing',
    note: '公園まで'
  },
  {
    id: 7,
    residentId: 1,
    title: '服薬確認',
    date: '2025-07-20',
    time: '08:00',
    category: 'medication',
    note: '血圧薬'
  },
  {
    id: 8,
    residentId: 2,
    title: '家族面会',
    date: '2025-07-22',
    time: '14:30',
    category: 'visit',
    note: '息子さん来訪予定'
  },
  {
    id: 9,
    residentId: 1,
    title: 'リハビリ',
    date: '2025-07-25',
    time: '11:00',
    category: 'rehabilitation',
    note: '作業療法'
  },
  {
    id: 10,
    residentId: 2,
    title: '通院（皮膚科）',
    date: '2025-07-28',
    time: '15:00',
    category: 'medical',
    note: '湿疹診察'
  }
];

const App = () => {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedResident, setSelectedResident] = useState(null);
  const [residents] = useState(mockResidents);
  const [notes, setNotes] = useState(mockNotes);
  const [medications] = useState(mockMedications);
  const [events, setEvents] = useState(mockEvents);
  const [contactBook] = useState(mockContactBook);
  const [supportPlans] = useState(mockSupportPlans);
  const [monitoring] = useState(mockMonitoring);
  const [meetingMinutes] = useState(mockMeetingMinutes);
  const [vitalRecords] = useState(mockVitalRecords);
  const [benefitCards] = useState(mockBenefitCards);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFacility, setSelectedFacility] = useState('');
  const [shiftData, setShiftData] = useState({
    '16:00-22:00': {
      '鮎川': ['山田 太郎'],
      '並木': ['佐藤 花子', '鈴木 一郎'],
      '末広': ['田中 美咲'],
      '大同': ['伊藤 健二'],
      '津之江': ['高橋 由美'],
      '寿町': ['渡辺 隆'],
      '古曽部': ['中村 恵子']
    },
    '22:00-09:00': {
      '鮎川': ['夜勤スタッフ 田村'],
      '並木': ['夜勤スタッフ 佐藤'],
      '末広': ['夜勤スタッフ 山本'],
      '大同': ['夜勤スタッフ 小林'],
      '津之江': ['夜勤スタッフ 青木'],
      '寿町': ['夜勤スタッフ 松田'],
      '古曽部': ['夜勤スタッフ 石川']
    }
  });
  const [moneyData, setMoneyData] = useState(
    residents.reduce((acc, resident) => {
      acc[resident.id] = [
        { date: '2025-07-08', balance: 50000, memo: '今月分入金' },
        { date: '2025-07-07', balance: 48500, memo: '買い物（日用品）' },
        { date: '2025-07-06', balance: 52000, memo: '' },
        { date: '2025-07-05', balance: 52000, memo: '残高確認' },
        { date: '2025-07-01', balance: 45000, memo: '月初残高' }
      ];
      return acc;
    }, {})
  );
  const [mealData, setMealData] = useState(() => {
    // 複数日のサンプルデータを生成
    const data = {};
    const today = new Date();
    const dates = [];
    
    // 今日から過去5日分の日付を生成
    for (let i = 0; i < 5; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      dates.push(date.toISOString().split('T')[0]);
    }
    
    dates.forEach((date, dateIndex) => {
      data[date] = {};
      residents.forEach(resident => {
        data[date][resident.id] = {
          breakfast: dateIndex === 0 ? '' : (Math.random() > 0.2 ? '✓' : ''),
          lunch: dateIndex === 0 ? '' : (Math.random() > 0.1 ? '✓' : ''),
          dinner: dateIndex === 0 ? '' : (Math.random() > 0.1 ? '✓' : ''),
        };
      });
    });
    
    return data;
  });
  const [selectedMealDate, setSelectedMealDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedMoneyResident, setSelectedMoneyResident] = useState(null);
  const [selectedShiftDate, setSelectedShiftDate] = useState(new Date('2025-07-11'));
  const [selectedMeetingResident, setSelectedMeetingResident] = useState(null);
  const [selectedBenefitResident, setSelectedBenefitResident] = useState(null);
  const [selectedPlanResident, setSelectedPlanResident] = useState(null);
  const [selectedMonitoringResident, setSelectedMonitoringResident] = useState(null);

  // ぽぽらすユーザーの場合、連絡帳タブを初期表示
  useEffect(() => {
    if (currentUser?.facility === 'ぽぽらす（福祉作業所）') {
      setActiveTab('contact-book');
    }
  }, [currentUser]);

  // Login component
  const LoginScreen = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [selectedFacility, setSelectedFacility] = useState('たぬきのお家（グループホーム）');

    const facilities = [
      'たぬきのお家（グループホーム）',
      'ぽぽらす（福祉作業所）',
      'かむとぅる（移動支援）',
      'その他の施設'
    ];

    const handleLogin = () => {
      if (email && password && selectedFacility) {
        setCurrentUser({
          id: 1,
          name: selectedFacility === 'たぬきのお家（グループホーム）' ? '鮎川' : 
                selectedFacility === 'ぽぽらす（福祉作業所）' ? 'ぽぽらすスタッフ' :
                selectedFacility === 'かむとぅる（移動支援）' ? 'かむとぅるスタッフ' : 'スタッフ',
          role: 'staff',
          facility: selectedFacility
        });
      }
    };

    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-200 w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-gray-700 mb-2">グループホーム</h1>
            <p className="text-gray-500">利用者情報共有システム</p>
          </div>
          <div>
            <div className="mb-4">
              <label className="block text-gray-600 text-sm font-medium mb-2">
                施設選択
              </label>
              <select
                value={selectedFacility}
                onChange={(e) => setSelectedFacility(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {facilities.map(facility => (
                  <option key={facility} value={facility}>{facility}</option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-gray-600 text-sm font-medium mb-2">
                メールアドレス
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="your-email@example.com"
              />
            </div>
            <div className="mb-6">
              <label className="block text-gray-600 text-sm font-medium mb-2">
                パスワード
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="パスワードを入力"
                onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
              />
            </div>
            <button
              onClick={handleLogin}
              className="w-full bg-blue-600 text-white p-3 rounded-md hover:bg-blue-700 transition-colors"
            >
              ログイン
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Sidebar component
  const Sidebar = () => {
    const menuItems = [
      { id: 'dashboard', label: 'ダッシュボード', icon: Home },
      { id: 'residents', label: '支援記録', icon: User },
      { id: 'contact-book', label: '連絡帳', icon: MessageSquare },
      { id: 'shift-table', label: 'シフト表', icon: Clock },
      { id: 'money-management', label: '金銭管理', icon: DollarSign },
      { id: 'meal-management', label: '食事管理', icon: Utensils },
      { id: 'medications', label: '服薬管理', icon: Pill },
      { id: 'support-plan', label: '個別支援計画', icon: FileText },
      { id: 'monitoring', label: 'モニタリング', icon: ClipboardList },
      { id: 'meeting-minutes', label: '支援会議議事録', icon: Users },
      { id: 'benefit-cards', label: '受給者証', icon: Calendar },
      { id: 'settings', label: '設定', icon: Settings }
    ];

    // ぽぽらすの場合は連絡帳のみ表示
    const filteredMenuItems = currentUser?.facility === 'ぽぽらす（福祉作業所）' 
      ? menuItems.filter(item => item.id === 'contact-book')
      : menuItems;

    return (
      <div className="w-64 bg-white border-r border-gray-200 h-screen">
        <div className="p-4 border-b border-gray-200">
          <h1 className="text-lg font-bold text-gray-700">グループホーム</h1>
          <p className="text-sm text-gray-500">{currentUser?.facility}</p>
        </div>
        <nav className="mt-4">
          {filteredMenuItems.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center px-4 py-3 text-left hover:bg-gray-50 transition-colors ${
                  activeTab === item.id ? 'bg-blue-50 text-blue-600 border-r-2 border-blue-600' : 'text-gray-600'
                }`}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="absolute bottom-4 left-4 right-4">
          <p className="text-sm text-gray-500">{currentUser?.name}</p>
          <button 
            onClick={() => setCurrentUser(null)}
            className="text-sm text-blue-600 hover:underline"
          >
            ログアウト
          </button>
        </div>
      </div>
    );
  };

  // Dashboard component
  const Dashboard = () => {
    const benefitAlerts = residents.filter(resident => resident.benefitCard.daysUntilExpiry <= 30);
    const recentNotes = notes.slice(0, 3);
    const todaysEvents = events.filter(event => event.date === '2025-07-08');
    const unreadContactBook = contactBook.filter(item => !item.isRead);

    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-700 mb-6">ダッシュボード</h2>
        
        {/* Alert section */}
        {benefitAlerts.length > 0 && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <div className="flex items-center mb-2">
              <AlertTriangle className="h-5 w-5 text-red-600 mr-2" />
              <h3 className="font-medium text-red-800">受給者証期限アラート</h3>
            </div>
            {benefitAlerts.map(resident => (
              <p key={resident.id} className="text-red-700 text-sm">
                {resident.name} - 受給者証期限: {resident.benefitCard.expiryDate} (残り{resident.benefitCard.daysUntilExpiry}日)
              </p>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Unread Contact Book */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-medium text-gray-700 mb-4">未読連絡帳</h3>
            <div className="space-y-3">
              {unreadContactBook.length > 0 ? (
                unreadContactBook.slice(0, 3).map(item => (
                  <div key={item.id} className="border-l-4 border-red-500 pl-3">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        item.priority === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {item.priority === 'high' ? '重要' : '通常'}
                      </span>
                      {item.imageUrl && (
                        <Camera className="h-3 w-3 text-blue-600" />
                      )}
                    </div>
                    <p className="text-sm font-medium text-gray-900">{item.title}</p>
                    <p className="text-sm text-gray-600 truncate">{item.content}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {item.author} ({item.timestamp})
                    </p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">未読の連絡帳はありません</p>
              )}
            </div>
          </div>

          {/* Recent Support Records */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-medium text-gray-700 mb-4">最近の支援記録</h3>
            <div className="space-y-3">
              {recentNotes.map(note => (
                <div key={note.id} className="border-l-4 border-blue-600 pl-3">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      note.authorType === 'facility' 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {note.facility}
                    </span>
                    {note.imageUrl && (
                      <span className="text-xs text-blue-600 flex items-center">
                        <Camera className="h-3 w-3 mr-1" />
                        画像あり
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{note.content}</p>
                  {note.memo && (
                    <p className="text-xs text-yellow-700 bg-yellow-50 p-1 rounded mt-1">伝達: {note.memo}</p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    {residents.find(r => r.id === note.residentId)?.name} - {note.author} ({note.timestamp})
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Today's schedule */}
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-medium text-gray-700 mb-4">本日の予定</h3>
            <div className="space-y-2">
              {todaysEvents.length > 0 ? (
                todaysEvents.map(event => {
                  const resident = residents.find(r => r.id === event.residentId);
                  return (
                    <div key={event.id} className="flex justify-between items-center py-2 border-b border-gray-100">
                      <span className="text-sm">{resident?.name} - {event.title}</span>
                      <span className="text-xs text-gray-500">{event.time}</span>
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-gray-500">本日の予定はありません</p>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Residents list component
  const ResidentsList = ({ selectedFacility, setSelectedFacility }) => {
    const facilities = ['鮎川', '並木', '末広', '大同', '津之江', '寿町', '古曽部'];
    
    const filteredResidents = residents.filter(resident => {
      const matchesSearch = resident.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFacility = selectedFacility === '' || resident.facility === selectedFacility;
      return matchesSearch && matchesFacility;
    });

    const getLatestSupportRecord = (residentId, supportType) => {
      const residentNotes = notes.filter(note => note.residentId === residentId && note.supportType === supportType);
      if (residentNotes.length === 0) return null;
      return residentNotes.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
    };

    const downloadPDF = () => {
      // PDFダウンロード機能（デモ用）
      const content = `
支援記録一覧レポート
生成日時: ${new Date().toLocaleDateString('ja-JP')}

${filteredResidents.map(resident => {
  const latestDayRecord = getLatestSupportRecord(resident.id, 'day');
  const latestNightRecord = getLatestSupportRecord(resident.id, 'night');
  return `
名前: ${resident.name}
利用施設: ${resident.facility}
最新日中支援記録: ${latestDayRecord ? latestDayRecord.memo || latestDayRecord.content : 'なし'}
最新夜間巡回記録: ${latestNightRecord ? latestNightRecord.memo || latestNightRecord.content : 'なし'}
---`;
}).join('\n')}
      `;
      
      const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `支援記録一覧_${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    };

    return (
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-700">支援記録一覧</h2>
          <div className="flex space-x-3">
            <button 
              onClick={downloadPDF}
              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center"
            >
              📄 PDFダウンロード
            </button>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
              <Plus className="h-4 w-4 mr-2" />
              新規登録
            </button>
          </div>
        </div>

        <div className="mb-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="利用者名で検索..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedFacility('')}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                selectedFacility === '' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              全て
            </button>
            {facilities.map(facility => (
              <button
                key={facility}
                onClick={() => setSelectedFacility(facility)}
                className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                  selectedFacility === facility 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {facility}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">利用者名</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">利用施設</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">支援記録（日中支援）</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">支援記録（夜間巡回）</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredResidents.map(resident => {
                const latestDayRecord = getLatestSupportRecord(resident.id, 'day');
                const latestNightRecord = getLatestSupportRecord(resident.id, 'night');
                return (
                  <tr key={resident.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                          <User className="h-6 w-6 text-gray-400" />
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{resident.name}</div>
                          <div className="text-sm text-gray-500">{resident.gender}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                        {resident.facility}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {latestDayRecord ? (
                        <div className="max-w-xs">
                          <p className="text-sm text-gray-900 truncate">{latestDayRecord.memo || latestDayRecord.content}</p>
                          <p className="text-xs text-gray-500">{latestDayRecord.timestamp}</p>
                          <p className="text-xs text-gray-600">記録者: {latestDayRecord.author}</p>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">記録なし</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {latestNightRecord ? (
                        <div className="max-w-xs">
                          <p className="text-sm text-gray-900 truncate">{latestNightRecord.memo || latestNightRecord.content}</p>
                          <p className="text-xs text-gray-500">{latestNightRecord.timestamp}</p>
                          <p className="text-xs text-gray-600">記録者: {latestNightRecord.author}</p>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">記録なし</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => setSelectedResident(resident)}
                        className="text-blue-600 hover:text-blue-900 mr-3"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button className="text-gray-600 hover:text-gray-900">
                        <Edit className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 text-sm text-gray-600">
          {filteredResidents.length}件の支援記録が表示されています
        </div>
      </div>
    );
  };

  // Resident detail component
  const ResidentDetail = ({ resident }) => {
    const [activeDetailTab, setActiveDetailTab] = useState('profile');
    const residentNotes = notes.filter(note => note.residentId === resident.id);
    const residentMeds = medications.filter(med => med.residentId === resident.id);

    const detailTabs = [
      { id: 'profile', label: 'プロフィール' },
      { id: 'vitals', label: 'バイタル' },
      { id: 'notes', label: '支援記録' },
      { id: 'medications', label: '服薬' },
      { id: 'schedule', label: '予定' }
    ];

    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <button 
              onClick={() => setSelectedResident(null)}
              className="text-blue-600 hover:text-blue-800 mr-4"
            >
              ← 戻る
            </button>
            <h2 className="text-2xl font-bold text-gray-700">{resident.name}</h2>
          </div>
        </div>

        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            {detailTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveDetailTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm ${
                  activeDetailTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {activeDetailTab === 'profile' && (
          <div className="space-y-6">
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <h3 className="text-lg font-medium text-gray-700 mb-4">基本情報</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">名前</label>
                  <p className="text-gray-900">{resident.name}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">年齢</label>
                  <p className="text-gray-900">{resident.age}歳</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">性別</label>
                  <p className="text-gray-900">{resident.gender}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">区分</label>
                  <p className="text-gray-900">{resident.careLevel}</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">利用施設</label>
                  <p className="text-gray-900">{resident.facility}</p>
                </div>
                <div className="col-span-1">
                  <label className="block text-sm font-medium text-gray-600 mb-1">アレルギー</label>
                  <p className="text-gray-900">{resident.allergies}</p>
                </div>
              </div>
            </div>

            <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
              基本情報を編集
            </button>
          </div>
        )}

        {activeDetailTab === 'vitals' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-700">バイタル記録</h3>
              <div className="flex space-x-2">
                <button 
                  onClick={() => {
                    // エクセルダウンロード機能
                    const csvContent = `日付,時間,体温(°C),収縮期血圧,拡張期血圧,脈拍,備考\n${
                      vitalRecords
                        .filter(record => record.residentId === resident.id)
                        .map(record => 
                          `${record.date},${record.time},${record.temperature},${record.bloodPressureSys},${record.bloodPressureDia},${record.pulse},"${record.memo}"`
                        ).join('\n')
                    }`;
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = `${resident.name}_バイタル記録_${new Date().toISOString().split('T')[0]}.csv`;
                    link.click();
                  }}
                  className="bg-green-600 text-white px-3 py-1 rounded-md hover:bg-green-700 transition-colors flex items-center text-sm"
                >
                  <Download className="h-4 w-4 mr-1" />
                  エクセル出力
                </button>
                <button className="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 transition-colors flex items-center text-sm">
                  <Plus className="h-4 w-4 mr-1" />
                  記録追加
                </button>
              </div>
            </div>

            {/* 情報メッセージ */}
            <div className="mb-4 bg-purple-50 border border-purple-200 rounded-lg p-4">
              <p className="text-purple-800 text-sm">
                💡 「7月分サンプルデータ」ボタンをクリックすると、2025年7月1日〜31日の全利用者の食事記録例がダウンロードできます。
                データ入力の参考にご活用ください。
              </p>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">日付</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">時間</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">体温(°C)</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">収縮期血圧</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">拡張期血圧</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">脈拍</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase border-b">備考</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white">
                    {vitalRecords
                      .filter(record => record.residentId === resident.id)
                      .sort((a, b) => new Date(b.date + ' ' + b.time) - new Date(a.date + ' ' + a.time))
                      .map((record, index) => (
                        <tr key={record.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-4 py-3 border-b text-gray-900">{record.date}</td>
                          <td className="px-4 py-3 border-b text-gray-900">{record.time}</td>
                          <td className="px-4 py-3 border-b text-gray-900">{record.temperature}</td>
                          <td className="px-4 py-3 border-b text-gray-900">{record.bloodPressureSys}</td>
                          <td className="px-4 py-3 border-b text-gray-900">{record.bloodPressureDia}</td>
                          <td className="px-4 py-3 border-b text-gray-900">{record.pulse}</td>
                          <td className="px-4 py-3 border-b text-gray-600">{record.memo || '-'}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeDetailTab === 'notes' && (
          <div className="space-y-4">
            <NotesManager residentId={resident.id} />
          </div>
        )}

        {activeDetailTab === 'medications' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-700">服薬情報</h3>
              <button className="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 transition-colors flex items-center text-sm">
                <Plus className="h-4 w-4 mr-1" />
                服薬追加
              </button>
            </div>
            {residentMeds.map(med => {
              const isExpiringSoon = new Date(med.prescriptionEndDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
              return (
                <div key={med.id} className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{med.drugName}</h4>
                      <p className="text-sm text-gray-600">{med.dosage}</p>
                      <p className="text-sm text-gray-600">処方医: {med.prescribedBy}</p>
                      <p className="text-xs text-gray-500">最終確認: {med.lastChecked}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-medium ${isExpiringSoon ? 'text-red-600' : 'text-gray-600'}`}>
                        処方終了: {med.prescriptionEndDate}
                      </p>
                      {isExpiringSoon && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 mt-1">
                          期限間近
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {med.prescriptionImage && (
                    <div className="mb-3">
                      <img 
                        src={med.prescriptionImage} 
                        alt="処方箋" 
                        className="w-48 h-32 object-cover rounded border shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => window.open(med.prescriptionImage, '_blank')}
                      />
                      <p className="text-xs text-gray-500 mt-1">📄 処方箋画像（クリックで拡大）</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {activeDetailTab === 'schedule' && (
          <div className="bg-white border border-gray-200 rounded-lg p-4">
            <h3 className="font-medium text-gray-700">スケジュール機能</h3>
            <p className="text-gray-500 mt-2">個別カレンダー機能は開発中です</p>
          </div>
        )}
      </div>
    );
  };

  // Notes management component (Support Records)
  const NotesManager = ({ residentId }) => {
    const [showAddNoteModal, setShowAddNoteModal] = useState(false);
    const residentNotes = notes.filter(note => note.residentId === residentId);

    const AddNoteForm = () => {
      const [formData, setFormData] = useState({
        content: '',
        authorType: 'facility',
        facility: 'たぬきのお家（グループホーム）',
        tags: [],
        imageFile: null,
        memo: '',
        supportType: 'day' // 追加: 日中支援/夜間巡回の選択
      });

      const [newTag, setNewTag] = useState('');

      const facilityOptions = [
        { value: 'たぬきのお家（グループホーム）', type: 'facility' },
        { value: 'ぽぽらす（通所先）', type: 'dayservice' },
        { value: 'たんぽぽ（通所先）', type: 'dayservice' }
      ];

      const tagOptions = ['食事', 'バイタル', '体調', 'リハビリ', '外出', '面会', '服薬', 'レクリエーション', '歩行', '拒否', 'その他'];

      const handleSubmit = () => {
        if (formData.content.trim()) {
          const selectedFacility = facilityOptions.find(f => f.value === formData.facility);
          const newNote = {
            id: notes.length + 1,
            residentId: residentId,
            content: formData.content,
            author: '鮎川' || '不明',
            authorType: selectedFacility?.type || 'facility',
            facility: formData.facility,
            timestamp: new Date().toLocaleString('ja-JP', {
              year: 'numeric', month: '2-digit', day: '2-digit',
              hour: '2-digit', minute: '2-digit'
            }).replace(/\//g, '-'),
            tags: formData.tags,
            imageUrl: formData.imageFile ? 'uploaded-image.jpg' : null,
            memo: formData.memo,
            supportType: formData.supportType // 追加
          };
          setNotes([newNote, ...notes]);
          setShowAddNoteModal(false);
          setFormData({
            content: '',
            authorType: 'facility',
            facility: 'たぬきのお家（グループホーム）',
            tags: [],
            imageFile: null,
            memo: '',
            supportType: 'day'
          });
        }
      };

      const addTag = (tag) => {
        if (!formData.tags.includes(tag)) {
          setFormData({...formData, tags: [...formData.tags, tag]});
        }
      };

      const removeTag = (tagToRemove) => {
        setFormData({
          ...formData, 
          tags: formData.tags.filter(tag => tag !== tagToRemove)
        });
      };

      const handleImageUpload = (e) => {
        const file = e.target.files[0];
        if (file) {
          setFormData({...formData, imageFile: file});
        }
      };

      if (!showAddNoteModal) return null;

      return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">支援記録を追加</h3>
              <button 
                onClick={() => setShowAddNoteModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  記録場所 *
                </label>
                <select
                  value={formData.facility}
                  onChange={(e) => setFormData({...formData, facility: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  {facilityOptions.map(option => (
                    <option key={option.value} value={option.value}>
                      {option.value}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  支援区分 *
                </label>
                <select
                  value={formData.supportType}
                  onChange={(e) => setFormData({...formData, supportType: e.target.value})}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="day">日中支援</option>
                  <option value="night">夜間巡回</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  支援内容 *
                </label>
                <textarea
                  value={formData.content}
                  onChange={(e) => setFormData({...formData, content: e.target.value})}
                  rows={4}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="支援記録の内容を入力してください"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  伝達事項・備考
                </label>
                <textarea
                  value={formData.memo}
                  onChange={(e) => setFormData({...formData, memo: e.target.value})}
                  rows={2}
                  className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="他施設への伝達事項や備考を入力してください"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  写真添付
                </label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label
                      htmlFor="image-upload"
                      className="flex items-center px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 cursor-pointer"
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      写真を選択
                    </label>
                    {formData.imageFile && (
                      <span className="text-sm text-gray-600">{formData.imageFile.name}</span>
                    )}
                  </div>
                  {formData.imageFile && (
                    <div className="mt-2">
                      <img 
                        src={URL.createObjectURL(formData.imageFile)} 
                        alt="プレビュー" 
                        className="w-32 h-24 object-cover rounded border"
                      />
                      <p className="text-xs text-gray-500 mt-1">プレビュー</p>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  タグ
                </label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {formData.tags.map(tag => (
                    <span 
                      key={tag}
                      className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs flex items-center"
                    >
                      {tag}
                      <button 
                        onClick={() => removeTag(tag)}
                        className="ml-1 text-blue-600 hover:text-blue-800"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
                <div className="flex flex-wrap gap-1">
                  {tagOptions.map(tag => (
                    <button
                      key={tag}
                      onClick={() => addTag(tag)}
                      className="px-2 py-1 text-xs border border-gray-300 rounded hover:bg-gray-50"
                      disabled={formData.tags.includes(tag)}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowAddNoteModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors"
              >
                キャンセル
              </button>
              <button
                onClick={handleSubmit}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                保存
              </button>
            </div>
          </div>
        </div>
      );
    };

    return (
      <div className="space-y-4">
        <button 
          onClick={() => setShowAddNoteModal(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center"
        >
          <Plus className="h-4 w-4 mr-2" />
          支援記録を追加
        </button>
        
        <div className="space-y-3">
          {residentNotes.map(note => (
            <div key={note.id} className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    note.authorType === 'facility' 
                      ? 'bg-blue-100 text-blue-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {note.facility}
                  </span>
                  <div className="flex space-x-1">
                    {note.tags.map(tag => (
                      <span key={tag} className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <span className="text-xs text-gray-500">{note.timestamp}</span>
              </div>
              <p className="text-gray-900 mb-2">{note.content}</p>
              {note.memo && (
                <div className="bg-yellow-50 border border-yellow-200 rounded p-2 mb-2">
                  <p className="text-sm text-yellow-800"><strong>伝達事項:</strong> {note.memo}</p>
                </div>
              )}
              {note.imageUrl && (
                <div className="mb-2">
                  <img 
                    src={note.imageUrl} 
                    alt="支援記録画像" 
                    className="w-48 h-32 object-cover rounded border shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => window.open(note.imageUrl, '_blank')}
                  />
                  <p className="text-xs text-gray-500 mt-1">📷 添付画像（クリックで拡大）</p>
                </div>
              )}
              <p className="text-sm text-gray-600">記録者: {note.author}</p>
            </div>
          ))}
        </div>

        <AddNoteForm />
      </div>
    );
  };

  const renderContent = () => {
    if (selectedResident) {
      return <ResidentDetail resident={selectedResident} />;
    }

    // ぽぽらすユーザーは連絡帳のみアクセス可能
    if (currentUser?.facility === 'ぽぽらす（福祉作業所）' && activeTab !== 'contact-book') {
      return (
        <div className="p-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
            <h2 className="text-xl font-bold text-blue-800 mb-4">アクセス制限</h2>
            <p className="text-blue-700 mb-4">
              ぽぽらす（福祉作業所）のアカウントでは連絡帳のみご利用いただけます。
            </p>
            <button 
              onClick={() => setActiveTab('contact-book')}
              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
            >
              連絡帳に移動
            </button>
          </div>
        </div>
      );
    }

    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'residents':
        return <ResidentsList selectedFacility={selectedFacility} setSelectedFacility={setSelectedFacility} />;
      case 'shift-table':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">
              シフト表
              <span className="text-lg font-normal text-gray-600 ml-3">
                {selectedShiftDate.toLocaleDateString('ja-JP', { year: 'numeric', month: 'numeric', day: 'numeric' })}
              </span>
            </h2>
            
            <div className="mb-6 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const newDate = new Date(selectedShiftDate);
                    newDate.setDate(newDate.getDate() - 1);
                    setSelectedShiftDate(newDate);
                  }}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <ChevronLeft className="h-5 w-5 text-gray-600" />
                </button>
                <div className="text-sm text-gray-600 px-3">
                  {selectedShiftDate.toLocaleDateString('ja-JP', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric',
                    weekday: 'long'
                  })}
                  {selectedShiftDate.toDateString() === new Date().toDateString() && (
                    <span className="text-green-600 font-medium ml-2">（本日）</span>
                  )}
                </div>
                <button
                  onClick={() => {
                    const newDate = new Date(selectedShiftDate);
                    newDate.setDate(newDate.getDate() + 1);
                    setSelectedShiftDate(newDate);
                  }}
                  className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <ChevronRight className="h-5 w-5 text-gray-600" />
                </button>
                <button
                  onClick={() => setSelectedShiftDate(new Date())}
                  className="ml-4 px-3 py-1 text-sm text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-md transition-colors"
                >
                  今日へ
                </button>
              </div>
              <div className="flex space-x-2">
                <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  エクセル出力
                </button>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                  <Edit className="h-4 w-4 mr-2" />
                  編集モード
                </button>
              </div>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200">
                        時間帯
                      </th>
                      {['鮎川', '並木', '末広', '大同', '津之江', '寿町', '古曽部'].map(facility => (
                        <th key={facility} className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider border-r border-gray-200">
                          {facility}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {Object.entries(shiftData).map(([timeSlot, facilities]) => (
                      <tr key={timeSlot} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 border-r border-gray-200">
                          {timeSlot === '16:00-22:00' ? (
                            <span className="flex items-center">
                              <span className="inline-block w-3 h-3 bg-yellow-400 rounded-full mr-2"></span>
                              16:00 ～ 22:00
                            </span>
                          ) : (
                            <span className="flex items-center">
                              <span className="inline-block w-3 h-3 bg-blue-600 rounded-full mr-2"></span>
                              22:00 ～ 9:00
                            </span>
                          )}
                        </td>
                        {['鮎川', '並木', '末広', '大同', '津之江', '寿町', '古曽部'].map(facility => (
                          <td key={facility} className="px-6 py-4 text-center border-r border-gray-200">
                            <div className="text-sm text-gray-900">
                              {facilities[facility] && facilities[facility].length > 0 ? (
                                facilities[facility].map((staff, index) => (
                                  <div key={index} className={`${index > 0 ? 'mt-1' : ''}`}>
                                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                                      timeSlot === '22:00-09:00' 
                                        ? 'bg-blue-100 text-blue-800' 
                                        : 'bg-yellow-100 text-yellow-800'
                                    }`}>
                                      {staff}
                                    </span>
                                  </div>
                                ))
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 凡例 */}
            <div className="mt-4 flex items-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center">
                <span className="inline-block w-3 h-3 bg-yellow-400 rounded-full mr-2"></span>
                <span>日勤（16:00～22:00）</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-3 h-3 bg-blue-600 rounded-full mr-2"></span>
                <span>夜勤（22:00～9:00）</span>
              </div>
            </div>

            {/* スタッフ統計 */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">
                  {selectedShiftDate.toDateString() === new Date().toDateString() ? '本日' : '選択日'}の勤務者数
                </h4>
                <div className="text-2xl font-bold text-blue-600">14名</div>
                <p className="text-sm text-gray-600 mt-1">日勤: 7名 / 夜勤: 7名</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">配置充足率</h4>
                <div className="text-2xl font-bold text-green-600">100%</div>
                <p className="text-sm text-gray-600 mt-1">全施設配置完了</p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">次回シフト更新</h4>
                <div className="text-lg font-bold text-gray-700">7月15日（月）</div>
                <p className="text-sm text-gray-600 mt-1">残り7日</p>
              </div>
            </div>
          </div>
        );
      case 'money-management':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">金銭管理</h2>
            
            {selectedMoneyResident ? (
              // 利用者詳細画面
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <button 
                      onClick={() => setSelectedMoneyResident(null)}
                      className="text-blue-600 hover:text-blue-800 mr-4"
                    >
                      ← 戻る
                    </button>
                    <h3 className="text-xl font-bold text-gray-700">{selectedMoneyResident.name}さんの金銭管理</h3>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      onClick={() => {
                        const records = moneyData[selectedMoneyResident.id] || [];
                        const csvContent = `日付,残高(円),備考\n${
                          records.map(record => 
                            `${record.date},${record.balance},"${record.memo || ''}"`
                          ).join('\n')
                        }`;
                        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                        const link = document.createElement('a');
                        link.href = URL.createObjectURL(blob);
                        link.download = `${selectedMoneyResident.name}_金銭管理_${new Date().toISOString().split('T')[0]}.csv`;
                        link.click();
                      }}
                      className="bg-green-600 text-white px-3 py-1 rounded-md hover:bg-green-700 transition-colors flex items-center text-sm"
                    >
                      <Download className="h-4 w-4 mr-1" />
                      エクセル出力
                    </button>
                    <button 
                      onClick={() => {
                        const date = prompt('日付を入力してください (YYYY-MM-DD):', new Date().toISOString().split('T')[0]);
                        if (!date) return;
                        const balance = prompt('残高を入力してください:');
                        if (!balance || isNaN(parseInt(balance))) return;
                        const memo = prompt('備考を入力してください（任意）:') || '';
                        
                        const newRecord = {
                          date,
                          balance: parseInt(balance),
                          memo
                        };
                        
                        const currentRecords = moneyData[selectedMoneyResident.id] || [];
                        const updatedRecords = [...currentRecords, newRecord].sort((a, b) => new Date(b.date) - new Date(a.date));
                        
                        setMoneyData({
                          ...moneyData,
                          [selectedMoneyResident.id]: updatedRecords
                        });
                      }}
                      className="bg-blue-600 text-white px-3 py-1 rounded-md hover:bg-blue-700 transition-colors flex items-center text-sm"
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      記録追加
                    </button>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg p-4 mb-4">
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">現在の残高:</span>
                      <p className="text-2xl font-bold text-blue-600">
                        ¥{((moneyData[selectedMoneyResident.id]?.[0]?.balance || 0)).toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">前回との差額:</span>
                      <p className="text-xl font-bold">
                        {moneyData[selectedMoneyResident.id]?.length > 1 ? (
                          <span className={moneyData[selectedMoneyResident.id][0].balance - moneyData[selectedMoneyResident.id][1].balance >= 0 ? 'text-green-600' : 'text-red-600'}>
                            {moneyData[selectedMoneyResident.id][0].balance - moneyData[selectedMoneyResident.id][1].balance >= 0 ? '+' : ''}
                            ¥{(moneyData[selectedMoneyResident.id][0].balance - moneyData[selectedMoneyResident.id][1].balance).toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </p>
                    </div>
                    <div>
                      <span className="text-gray-600">最終更新:</span>
                      <p className="text-lg font-medium text-gray-900">
                        {moneyData[selectedMoneyResident.id]?.[0]?.date || '-'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">日付</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">残高</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">増減</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">備考</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {(moneyData[selectedMoneyResident.id] || []).map((record, index) => {
                        const prevBalance = moneyData[selectedMoneyResident.id]?.[index + 1]?.balance;
                        const change = prevBalance ? record.balance - prevBalance : 0;
                        return (
                          <tr key={`${record.date}-${index}`} className="hover:bg-gray-50">
                            <td className="px-4 py-3 text-gray-900">{record.date}</td>
                            <td className="px-4 py-3 font-medium text-gray-900">¥{record.balance.toLocaleString()}</td>
                            <td className="px-4 py-3">
                              {prevBalance ? (
                                <span className={change >= 0 ? 'text-green-600' : 'text-red-600'}>
                                  {change >= 0 ? '+' : ''}¥{change.toLocaleString()}
                                </span>
                              ) : (
                                <span className="text-gray-400">-</span>
                              )}
                            </td>
                            <td className="px-4 py-3 text-gray-600">{record.memo || '-'}</td>
                            <td className="px-4 py-3">
                              <button
                                onClick={() => {
                                  if (confirm('この記録を削除しますか？')) {
                                    const updatedRecords = moneyData[selectedMoneyResident.id].filter((_, i) => i !== index);
                                    setMoneyData({
                                      ...moneyData,
                                      [selectedMoneyResident.id]: updatedRecords
                                    });
                                  }
                                }}
                                className="text-red-600 hover:text-red-800"
                              >
                                削除
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              // 一覧画面
              <div>
                <div className="mb-4 flex justify-between items-center">
                  <p className="text-sm text-gray-600">
                    利用者をクリックして詳細な金銭管理記録を確認してください
                  </p>
                  <button 
                    onClick={() => {
                      const csvContent = `利用者名,施設,現在の残高(円),最終更新日\n${
                        residents.map(resident => {
                          const latestRecord = moneyData[resident.id]?.[0];
                          return `${resident.name},${resident.facility},${latestRecord?.balance || 0},${latestRecord?.date || '-'}`;
                        }).join('\n')
                      }`;
                      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                      const link = document.createElement('a');
                      link.href = URL.createObjectURL(blob);
                      link.download = `金銭管理一覧_${new Date().toISOString().split('T')[0]}.csv`;
                      link.click();
                    }}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    一覧をエクセル出力
                  </button>
                </div>

                <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">利用者名</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">施設</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">現在の残高</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">最終更新</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {residents.map(resident => {
                        const latestRecord = moneyData[resident.id]?.[0];
                        const isLowBalance = (latestRecord?.balance || 0) < 10000;
                        return (
                          <tr key={resident.id} className="hover:bg-gray-50 cursor-pointer" onClick={() => setSelectedMoneyResident(resident)}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center mr-3">
                                  <User className="h-6 w-6 text-gray-400" />
                                </div>
                                <div>
                                  <div className="text-sm font-medium text-gray-900">{resident.name}</div>
                                  <div className="text-sm text-gray-500">{resident.gender}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                {resident.facility}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <span className={`text-lg font-medium ${isLowBalance ? 'text-red-600' : 'text-gray-900'}`}>
                                  ¥{(latestRecord?.balance || 0).toLocaleString()}
                                </span>
                                {isLowBalance && (
                                  <AlertTriangle className="h-4 w-4 text-red-600 ml-2" />
                                )}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {latestRecord?.date || '-'}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedMoneyResident(resident);
                                }}
                                className="text-blue-600 hover:text-blue-900"
                              >
                                <Eye className="h-4 w-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* 統計情報 */}
                <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-700 mb-2">総残高</h4>
                    <div className="text-2xl font-bold text-blue-600">
                      ¥{residents.reduce((sum, resident) => {
                        const latestRecord = moneyData[resident.id]?.[0];
                        return sum + (latestRecord?.balance || 0);
                      }, 0).toLocaleString()}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">全利用者合計</p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-700 mb-2">平均残高</h4>
                    <div className="text-2xl font-bold text-green-600">
                      ¥{Math.floor(residents.reduce((sum, resident) => {
                        const latestRecord = moneyData[resident.id]?.[0];
                        return sum + (latestRecord?.balance || 0);
                      }, 0) / residents.length).toLocaleString()}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">利用者1人あたり</p>
                  </div>
                  <div className="bg-white border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-700 mb-2">残高10,000円未満</h4>
                    <div className="text-2xl font-bold text-red-600">
                      {residents.filter(resident => {
                        const latestRecord = moneyData[resident.id]?.[0];
                        return (latestRecord?.balance || 0) < 10000;
                      }).length}名
                    </div>
                    <p className="text-sm text-gray-600 mt-1">要確認</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      case 'meal-management':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">食事管理</h2>
            
            <div className="mb-6 flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      const newDate = new Date(selectedMealDate);
                      newDate.setDate(newDate.getDate() - 1);
                      setSelectedMealDate(newDate.toISOString().split('T')[0]);
                    }}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <ChevronLeft className="h-5 w-5 text-gray-600" />
                  </button>
                  <input
                    type="date"
                    value={selectedMealDate}
                    onChange={(e) => setSelectedMealDate(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={() => {
                      const newDate = new Date(selectedMealDate);
                      newDate.setDate(newDate.getDate() + 1);
                      setSelectedMealDate(newDate.toISOString().split('T')[0]);
                    }}
                    className="p-2 rounded-full hover:bg-gray-100 transition-colors"
                  >
                    <ChevronRight className="h-5 w-5 text-gray-600" />
                  </button>
                  <button
                    onClick={() => setSelectedMealDate(new Date().toISOString().split('T')[0])}
                    className="px-3 py-1 text-sm text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-md transition-colors"
                  >
                    今日へ
                  </button>
                </div>
                <div className="text-lg font-medium text-gray-700">
                  {new Date(selectedMealDate).toLocaleDateString('ja-JP', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric',
                    weekday: 'long'
                  })}
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button 
                  onClick={() => {
                    // 選択した月のサンプルデータを生成
                    const selectedDate = new Date(selectedMealDate);
                    const year = selectedDate.getFullYear();
                    const month = selectedDate.getMonth();
                    const daysInMonth = new Date(year, month + 1, 0).getDate();
                    
                    const dates = Array.from({length: daysInMonth}, (_, i) => {
                      const day = String(i + 1).padStart(2, '0');
                      return `${year}-${String(month + 1).padStart(2, '0')}-${day}`;
                    });
                    
                    const sampleData = [];
                    
                    residents.forEach(resident => {
                      dates.forEach(date => {
                        // ランダムだが現実的なデータを生成
                        const breakfast = Math.random() > 0.2 ? '✓' : '';
                        const lunch = Math.random() > 0.1 ? '✓' : '';
                        const dinner = Math.random() > 0.1 ? '✓' : '';
                        
                        sampleData.push({
                          date,
                          name: resident.name,
                          facility: resident.facility,
                          breakfast,
                          lunch,
                          dinner
                        });
                      });
                    });
                    
                    const csvContent = `日付,利用者名,施設,朝食,昼食,夕食\n${
                      sampleData.map(data => 
                        `${data.date},${data.name},${data.facility},${data.breakfast},${data.lunch},${data.dinner}`
                      ).join('\n')
                    }`;
                    
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = `食事管理_${year}年${month + 1}月_サンプルデータ.csv`;
                    link.click();
                  }}
                  className="bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors flex items-center"
                >
                  <Download className="h-4 w-4 mr-2" />
                  今月のサンプルデータ
                </button>
                <button 
                  onClick={() => {
                    const currentMealData = mealData[selectedMealDate] || {};
                    const csvContent = `利用者名,施設,朝食,昼食,夕食,記録日\n${
                      residents.map(resident => {
                        const meal = currentMealData[resident.id] || {};
                        return `${resident.name},${resident.facility},${meal.breakfast || ''},${meal.lunch || ''},${meal.dinner || ''},${selectedMealDate}`;
                      }).join('\n')
                    }`;
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement('a');
                    link.href = URL.createObjectURL(blob);
                    link.download = `食事管理_${selectedMealDate}.csv`;
                    link.click();
                  }}
                  className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center"
                >
                  <Download className="h-4 w-4 mr-2" />
                  この日のデータ出力
                </button>
              </div>
            </div>

            {/* 情報メッセージ */}
            <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">
                📅 日付を選択して、その日の食事記録を入力・閲覧できます。
                セルをクリックすると✓マークがつきます。もう一度クリックすると消えます。
              </p>
            </div>

            <div className="bg-white border border-gray-400 rounded-lg overflow-hidden shadow-lg">
              <table className="w-full border-collapse">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="border border-gray-400 px-4 py-2 text-left text-sm font-bold text-gray-700">利用者名</th>
                    <th className="border border-gray-400 px-4 py-2 text-left text-sm font-bold text-gray-700">施設</th>
                    <th className="border border-gray-400 px-4 py-2 text-center text-sm font-bold text-gray-700 bg-orange-50">朝食</th>
                    <th className="border border-gray-400 px-4 py-2 text-center text-sm font-bold text-gray-700 bg-yellow-50">昼食</th>
                    <th className="border border-gray-400 px-4 py-2 text-center text-sm font-bold text-gray-700 bg-blue-50">夕食</th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {residents.map((resident, index) => {
                    const currentMealData = mealData[selectedMealDate]?.[resident.id] || {};
                    return (
                      <tr key={resident.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="border border-gray-400 px-4 py-2">
                          <div className="text-sm font-medium text-gray-900">{resident.name}</div>
                        </td>
                        <td className="border border-gray-400 px-4 py-2">
                          <span className="text-sm text-gray-700">{resident.facility}</span>
                        </td>
                        <td 
                          className="border border-gray-400 px-4 py-2 text-center cursor-pointer hover:bg-orange-100 transition-colors"
                          onClick={() => {
                            setMealData({
                              ...mealData,
                              [selectedMealDate]: {
                                ...mealData[selectedMealDate],
                                [resident.id]: {
                                  ...currentMealData,
                                  breakfast: currentMealData.breakfast === '✓' ? '' : '✓'
                                }
                              }
                            });
                          }}
                        >
                          <span className="text-green-600 font-bold text-lg">{currentMealData.breakfast}</span>
                        </td>
                        <td 
                          className="border border-gray-400 px-4 py-2 text-center cursor-pointer hover:bg-yellow-100 transition-colors"
                          onClick={() => {
                            setMealData({
                              ...mealData,
                              [selectedMealDate]: {
                                ...mealData[selectedMealDate],
                                [resident.id]: {
                                  ...currentMealData,
                                  lunch: currentMealData.lunch === '✓' ? '' : '✓'
                                }
                              }
                            });
                          }}
                        >
                          <span className="text-green-600 font-bold text-lg">{currentMealData.lunch}</span>
                        </td>
                        <td 
                          className="border border-gray-400 px-4 py-2 text-center cursor-pointer hover:bg-blue-100 transition-colors"
                          onClick={() => {
                            setMealData({
                              ...mealData,
                              [selectedMealDate]: {
                                ...mealData[selectedMealDate],
                                [resident.id]: {
                                  ...currentMealData,
                                  dinner: currentMealData.dinner === '✓' ? '' : '✓'
                                }
                              }
                            });
                          }}
                        >
                          <span className="text-green-600 font-bold text-lg">{currentMealData.dinner}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* 統計情報 */}
            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">朝食摂取率</h4>
                <div className="text-2xl font-bold text-orange-600">
                  {Math.round((Object.values(mealData[selectedMealDate] || {}).filter(data => data.breakfast === '✓').length / residents.length) * 100)}%
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  {Object.values(mealData[selectedMealDate] || {}).filter(data => data.breakfast === '✓').length}/{residents.length}名
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">昼食摂取率</h4>
                <div className="text-2xl font-bold text-yellow-600">
                  {Math.round((Object.values(mealData[selectedMealDate] || {}).filter(data => data.lunch === '✓').length / residents.length) * 100)}%
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  {Object.values(mealData[selectedMealDate] || {}).filter(data => data.lunch === '✓').length}/{residents.length}名
                </p>
              </div>
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <h4 className="font-medium text-gray-700 mb-2">夕食摂取率</h4>
                <div className="text-2xl font-bold text-blue-600">
                  {Math.round((Object.values(mealData[selectedMealDate] || {}).filter(data => data.dinner === '✓').length / residents.length) * 100)}%
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  {Object.values(mealData[selectedMealDate] || {}).filter(data => data.dinner === '✓').length}/{residents.length}名
                </p>
              </div>
            </div>

            {/* 凡例 */}
            <div className="mt-4 flex items-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center">
                <span className="inline-block w-6 h-6 border border-gray-400 rounded mr-2 text-green-600 text-center leading-5 font-bold">✓</span>
                <span>摂取済み</span>
              </div>
              <div className="flex items-center">
                <span className="inline-block w-6 h-6 border border-gray-400 rounded mr-2 text-gray-400 text-center leading-6"></span>
                <span>未摂取または未入力</span>
              </div>
            </div>

            {/* 過去データの警告 */}
            {new Date(selectedMealDate) < new Date(new Date().toISOString().split('T')[0]) && (
              <div className="mt-4 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <p className="text-sm text-yellow-800">
                  ⚠️ 過去の記録を表示しています。編集する場合はご注意ください。
                </p>
              </div>
            )}
          </div>
        );
      case 'medications':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">服薬管理</h2>
            <div className="space-y-4">
              {medications.map(med => {
                const resident = residents.find(r => r.id === med.residentId);
                const isExpiringSoon = new Date(med.prescriptionEndDate) <= new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
                return (
                  <div key={med.id} className="bg-white border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-900">{resident?.name}</h4>
                        <p className="text-lg font-semibold text-gray-800">{med.drugName}</p>
                        <p className="text-sm text-gray-600">{med.dosage}</p>
                        <p className="text-sm text-gray-600">処方医: {med.prescribedBy}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-medium ${isExpiringSoon ? 'text-red-600' : 'text-gray-600'}`}>
                          処方終了: {med.prescriptionEndDate}
                        </p>
                        {isExpiringSoon && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 mt-1">
                            期限間近
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {med.prescriptionImage && (
                      <div className="mb-3">
                        <img 
                          src={med.prescriptionImage} 
                          alt="処方箋" 
                          className="w-48 h-32 object-cover rounded border shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => window.open(med.prescriptionImage, '_blank')}
                        />
                        <p className="text-xs text-gray-500 mt-1">📄 処方箋画像（クリックで拡大）</p>
                      </div>
                    )}
                    
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>最終確認: {med.lastChecked}</span>
                      <button className="text-blue-600 hover:text-blue-800">
                        編集
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      case 'support-plan':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">個別支援計画</h2>
            
            {selectedPlanResident ? (
              // 利用者詳細画面
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <button 
                      onClick={() => setSelectedPlanResident(null)}
                      className="text-blue-600 hover:text-blue-800 mr-4"
                    >
                      ← 戻る
                    </button>
                    <h3 className="text-xl font-bold text-gray-700">{selectedPlanResident.name}さんの個別支援計画</h3>
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    新しい計画を追加
                  </button>
                </div>

                <div className="space-y-4">
                  {supportPlans
                    .filter(plan => plan.residentId === selectedPlanResident.id)
                    .sort((a, b) => new Date(b.uploadDate) - new Date(a.uploadDate))
                    .map(plan => (
                      <div key={plan.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="text-lg font-medium text-gray-900 mb-2">{plan.title}</h4>
                            <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-4">
                              <div>
                                <span className="font-medium">作成日:</span> {plan.uploadDate}
                              </div>
                              <div>
                                <span className="font-medium">次回見直し:</span> {plan.nextReviewDate}
                              </div>
                            </div>
                            <div className="flex items-center space-x-2 text-sm">
                              <span className="text-gray-500">ファイル名:</span>
                              <span className="text-gray-700 font-medium">{plan.fileUrl}</span>
                            </div>
                          </div>
                          <div className="flex flex-col space-y-2">
                            <button 
                              onClick={() => {
                                // PDF表示機能（実際の実装では適切なPDFビューアーを使用）
                                alert(`${plan.title}を表示します`);
                              }}
                              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center text-sm"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              表示
                            </button>
                            <button 
                              onClick={() => {
                                // PDFダウンロード機能
                                const link = document.createElement('a');
                                link.href = '#'; // 実際のPDFファイルのURLを指定
                                link.download = plan.fileUrl;
                                link.click();
                                alert(`${plan.title}をダウンロードしました`);
                              }}
                              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center text-sm"
                            >
                              <Download className="h-4 w-4 mr-2" />
                              ダウンロード
                            </button>
                          </div>
                        </div>
                        
                        {/* 見直し期限が近い場合の警告 */}
                        {(() => {
                          const daysUntilReview = Math.ceil((new Date(plan.nextReviewDate) - new Date()) / (1000 * 60 * 60 * 24));
                          if (daysUntilReview <= 30 && daysUntilReview > 0) {
                            return (
                              <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-md">
                                <p className="text-sm text-orange-800">
                                  ⚠️ 次回見直しまで残り{daysUntilReview}日です
                                </p>
                              </div>
                            );
                          }
                          return null;
                        })()}
                      </div>
                    ))}
                </div>

                {/* 計画がない場合 */}
                {supportPlans.filter(plan => plan.residentId === selectedPlanResident.id).length === 0 && (
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
                    <p className="text-gray-600">個別支援計画が登録されていません</p>
                    <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                      計画を作成
                    </button>
                  </div>
                )}
              </div>
            ) : (
              // 一覧画面
              <div>
                <div className="mb-4">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    新しい計画を追加
                  </button>
                </div>
                
                <div className="grid grid-cols-8 gap-3">
                  {residents.map(resident => {
                    const residentPlans = supportPlans.filter(plan => plan.residentId === resident.id);
                    const latestPlan = residentPlans.sort((a, b) => new Date(b.uploadDate) - new Date(a.uploadDate))[0];
                    const nextReviewDate = latestPlan ? new Date(latestPlan.nextReviewDate) : null;
                    const daysUntilReview = nextReviewDate ? Math.ceil((nextReviewDate - new Date()) / (1000 * 60 * 60 * 24)) : null;
                    const needsReview = daysUntilReview && daysUntilReview <= 30;
                    
                    return (
                      <div 
                        key={resident.id} 
                        className={`bg-white border-2 rounded-lg p-3 hover:shadow-md transition-all cursor-pointer text-center ${
                          needsReview ? 'border-orange-300 hover:border-orange-400' : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedPlanResident(resident)}
                      >
                        <div className="flex flex-col items-center">
                          <h4 className="font-medium text-gray-900 text-sm">{resident.name}</h4>
                          {needsReview && (
                            <span className="mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              見直し時期
                            </span>
                          )}
                          {!latestPlan && (
                            <span className="mt-1 text-xs text-gray-500">
                              未作成
                            </span>
                          )}
                          {residentPlans.length > 0 && (
                            <span className="mt-1 text-xs text-gray-600">
                              {residentPlans.length}件
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      case 'monitoring':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">モニタリング</h2>
            
            {selectedMonitoringResident ? (
              // 利用者詳細画面
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <button 
                      onClick={() => setSelectedMonitoringResident(null)}
                      className="text-blue-600 hover:text-blue-800 mr-4"
                    >
                      ← 戻る
                    </button>
                    <h3 className="text-xl font-bold text-gray-700">{selectedMonitoringResident.name}さんのモニタリング報告</h3>
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    モニタリング報告を追加
                  </button>
                </div>

                <div className="space-y-4">
                  {monitoring
                    .filter(report => report.residentId === selectedMonitoringResident.id)
                    .sort((a, b) => new Date(b.reportDate) - new Date(a.reportDate))
                    .map(report => (
                      <div key={report.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="text-lg font-medium text-gray-900 mb-2">{report.title}</h4>
                            <div className="text-sm text-gray-600 mb-4">
                              <span className="font-medium">報告日:</span> {report.reportDate}
                            </div>
                            <div className="grid grid-cols-1 gap-3 mb-4">
                              <div>
                                <span className="text-sm font-medium text-gray-700">達成事項:</span>
                                <p className="text-sm text-gray-600 mt-1">{report.achievements}</p>
                              </div>
                              <div>
                                <span className="text-sm font-medium text-gray-700">次回目標:</span>
                                <p className="text-sm text-gray-600 mt-1">{report.nextGoals}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2 text-sm">
                              <span className="text-gray-500">ファイル名:</span>
                              <span className="text-gray-700 font-medium">{report.fileUrl}</span>
                            </div>
                          </div>
                          <div className="flex flex-col space-y-2">
                            <button 
                              onClick={() => {
                                // PDF表示機能
                                alert(`${report.title}を表示します`);
                              }}
                              className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center text-sm"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              表示
                            </button>
                            <button 
                              onClick={() => {
                                // PDFダウンロード機能
                                const link = document.createElement('a');
                                link.href = '#'; // 実際のPDFファイルのURLを指定
                                link.download = report.fileUrl;
                                link.click();
                                alert(`${report.title}をダウンロードしました`);
                              }}
                              className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors flex items-center text-sm"
                            >
                              <Download className="h-4 w-4 mr-2" />
                              ダウンロード
                            </button>
                          </div>
                        </div>
                        
                        {/* 更新推奨の警告 */}
                        {(() => {
                          const daysSinceReport = Math.ceil((new Date() - new Date(report.reportDate)) / (1000 * 60 * 60 * 24));
                          if (daysSinceReport > 90) {
                            return (
                              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
                                <p className="text-sm text-yellow-800">
                                  ⚠️ 最終報告から{daysSinceReport}日経過しています。更新を推奨します。
                                </p>
                              </div>
                            );
                          }
                          return null;
                        })()}
                      </div>
                    ))}
                </div>

                {/* 報告がない場合 */}
                {monitoring.filter(report => report.residentId === selectedMonitoringResident.id).length === 0 && (
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
                    <p className="text-gray-600">モニタリング報告が登録されていません</p>
                    <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                      報告を作成
                    </button>
                  </div>
                )}
              </div>
            ) : (
              // 一覧画面
              <div>
                <div className="mb-4">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    モニタリング報告を追加
                  </button>
                </div>
                
                <div className="grid grid-cols-8 gap-3">
                  {residents.map(resident => {
                    const residentReports = monitoring.filter(report => report.residentId === resident.id);
                    const latestReport = residentReports.sort((a, b) => new Date(b.reportDate) - new Date(a.reportDate))[0];
                    const lastReportDate = latestReport ? new Date(latestReport.reportDate) : null;
                    const daysSinceReport = lastReportDate ? Math.ceil((new Date() - lastReportDate) / (1000 * 60 * 60 * 24)) : null;
                    const needsUpdate = daysSinceReport && daysSinceReport > 90;
                    
                    return (
                      <div 
                        key={resident.id} 
                        className={`bg-white border-2 rounded-lg p-3 hover:shadow-md transition-all cursor-pointer text-center ${
                          needsUpdate ? 'border-yellow-300 hover:border-yellow-400' : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedMonitoringResident(resident)}
                      >
                        <div className="flex flex-col items-center">
                          <h4 className="font-medium text-gray-900 text-sm">{resident.name}</h4>
                          {needsUpdate && (
                            <span className="mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              更新推奨
                            </span>
                          )}
                          {!latestReport && (
                            <span className="mt-1 text-xs text-gray-500">
                              未作成
                            </span>
                          )}
                          {residentReports.length > 0 && (
                            <span className="mt-1 text-xs text-gray-600">
                              {residentReports.length}件
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      case 'meeting-minutes':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">支援会議議事録</h2>
            
            {selectedMeetingResident ? (
              // 利用者詳細画面
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <button 
                      onClick={() => setSelectedMeetingResident(null)}
                      className="text-blue-600 hover:text-blue-800 mr-4"
                    >
                      ← 戻る
                    </button>
                    <h3 className="text-xl font-bold text-gray-700">{selectedMeetingResident.name}さんの支援会議議事録</h3>
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    議事録を追加
                  </button>
                </div>

                <div className="space-y-4">
                  {meetingMinutes
                    .filter(meeting => meeting.residentId === selectedMeetingResident.id)
                    .sort((a, b) => new Date(b.meetingDate) - new Date(a.meetingDate))
                    .map(meeting => (
                      <div key={meeting.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="text-lg font-medium text-gray-900 mb-1">{meeting.title}</h4>
                            <p className="text-sm text-gray-500">開催日: {meeting.meetingDate}</p>
                          </div>
                          <div className="flex space-x-2">
                            <button className="text-blue-600 hover:text-blue-800 text-sm">
                              閲覧
                            </button>
                            <button className="text-green-600 hover:text-green-800 text-sm">
                              ダウンロード
                            </button>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <div>
                            <span className="text-sm font-medium text-gray-700">参加者:</span>
                            <p className="text-sm text-gray-600">{meeting.participants}</p>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-gray-700">内容:</span>
                            <p className="text-sm text-gray-600">{meeting.summary}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ) : (
              // 一覧画面 - 4列固定表示
              <div>
                <div className="mb-4">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    議事録を追加
                  </button>
                </div>
                
                <div className="grid grid-cols-8 gap-3">
                  {residents.map(resident => {
                    const residentMeetings = meetingMinutes.filter(meeting => meeting.residentId === resident.id);
                    const latestMeeting = residentMeetings.sort((a, b) => new Date(b.meetingDate) - new Date(a.meetingDate))[0];
                    const lastMeetingDate = latestMeeting ? new Date(latestMeeting.meetingDate) : null;
                    const daysSinceMeeting = lastMeetingDate ? Math.ceil((new Date() - lastMeetingDate) / (1000 * 60 * 60 * 24)) : null;
                    const needsMeeting = daysSinceMeeting && daysSinceMeeting > 60;
                    
                    return (
                      <div 
                        key={resident.id} 
                        className={`bg-white border-2 rounded-lg p-3 hover:shadow-md transition-all cursor-pointer text-center ${
                          needsMeeting ? 'border-purple-300 hover:border-purple-400' : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedMeetingResident(resident)}
                      >
                        <div className="flex flex-col items-center">
                          <h4 className="font-medium text-gray-900 text-sm">{resident.name}</h4>
                          {needsMeeting && (
                            <span className="mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              会議推奨
                            </span>
                          )}
                          {!latestMeeting && (
                            <span className="mt-1 text-xs text-gray-500">
                              議事録なし
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      case 'contact-book':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">連絡帳</h2>
            
            {/* 権限チェック：たぬきのお家、ぽぽらす、かむとぅるの場合のみ追加ボタン表示 */}
            {(currentUser?.facility === 'たぬきのお家（グループホーム）' || 
              currentUser?.facility === 'ぽぽらす（福祉作業所）' || 
              currentUser?.facility === 'かむとぅる（移動支援）') && (
              <div className="mb-4">
                <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                  <Plus className="h-4 w-4 mr-2" />
                  連絡事項を追加
                </button>
              </div>
            )}
            
            {/* 権限がない場合の説明文 */}
            {!(currentUser?.facility === 'たぬきのお家（グループホーム）' || 
              currentUser?.facility === 'ぽぽらす（福祉作業所）' || 
              currentUser?.facility === 'かむとぅる（移動支援）') && (
              <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm">
                  📖 こちらは連絡帳の閲覧専用です。投稿はグループホーム、福祉作業所、移動支援のスタッフが行います。
                </p>
              </div>
            )}
            
            <div className="space-y-4">
              {contactBook.map(item => (
                <div key={item.id} className={`bg-white border-2 rounded-lg p-4 ${!item.isRead ? 'border-red-200 bg-red-50' : 'border-gray-200'}`}>
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-medium text-gray-900">{item.title}</h4>
                      {!item.isRead && (
                        <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          未読
                        </span>
                      )}
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        item.priority === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {item.priority === 'high' ? '重要' : '通常'}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">{item.timestamp}</span>
                  </div>
                  <p className="text-gray-700 mb-3">{item.content}</p>
                  {item.imageUrl && (
                    <div className="mb-3">
                      <img 
                        src={item.imageUrl} 
                        alt="連絡帳画像" 
                        className="w-48 h-32 object-cover rounded border shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => window.open(item.imageUrl, '_blank')}
                      />
                      <p className="text-xs text-gray-500 mt-1">📷 添付画像（クリックで拡大）</p>
                    </div>
                  )}
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">投稿者: {item.author}</span>
                    {!item.isRead && (
                      <button className="text-blue-600 hover:text-blue-800 text-sm">
                        既読にする
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'benefit-cards':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">受給者証管理</h2>
            
            {selectedBenefitResident ? (
              // 利用者詳細画面
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <button 
                      onClick={() => setSelectedBenefitResident(null)}
                      className="text-blue-600 hover:text-blue-800 mr-4"
                    >
                      ← 戻る
                    </button>
                    <h3 className="text-xl font-bold text-gray-700">{selectedBenefitResident.name}さんの受給者証</h3>
                  </div>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    受給者証を追加
                  </button>
                </div>

                <div className="space-y-4">
                  {benefitCards
                    .filter(card => card.residentId === selectedBenefitResident.id)
                    .map(card => {
                      const isExpiring = card.daysUntilExpiry <= 30;
                      return (
                        <div key={card.id} className={`border-2 rounded-lg p-6 ${
                          isExpiring ? 'border-red-200 bg-red-50' : 'border-gray-200 bg-white'
                        }`}>
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h4 className={`text-lg font-medium ${
                                card.serviceType === 'グループホーム' ? 'text-blue-800' :
                                card.serviceType === '福祉作業' ? 'text-green-800' :
                                card.serviceType === '移動支援' ? 'text-purple-800' :
                                'text-gray-800'
                              }`}>
                                {card.serviceType}
                              </h4>
                              <p className="text-sm text-gray-600 mt-1">
                                月間利用時間: {card.monthlyHours}時間
                              </p>
                            </div>
                            <div className="text-right">
                              {isExpiring && (
                                <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800 mb-2">
                                  <AlertTriangle className="h-4 w-4 mr-1" />
                                  期限間近
                                </div>
                              )}
                              <div className={`text-2xl font-bold ${isExpiring ? 'text-red-600' : 'text-gray-700'}`}>
                                残り{card.daysUntilExpiry}日
                              </div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-gray-700">支給開始日:</span>
                              <p className="text-gray-600">{card.startDate}</p>
                            </div>
                            <div>
                              <span className="font-medium text-gray-700">支給終了日:</span>
                              <p className={`${isExpiring ? 'text-red-600 font-medium' : 'text-gray-600'}`}>
                                {card.endDate}
                              </p>
                            </div>
                          </div>
                          
                          {isExpiring && (
                            <div className="mt-4 p-3 bg-red-100 border border-red-200 rounded-md">
                              <p className="text-sm text-red-800">
                                ⚠️ 受給者証の更新手続きが必要です。関係機関にお問い合わせください。
                              </p>
                            </div>
                          )}
                          
                          <div className="mt-4 flex justify-end space-x-2">
                            <button className="text-blue-600 hover:text-blue-800 text-sm">
                              編集
                            </button>
                            <button className="text-green-600 hover:text-green-800 text-sm">
                              PDFダウンロード
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>

                {/* 利用者の受給者証がない場合 */}
                {benefitCards.filter(card => card.residentId === selectedBenefitResident.id).length === 0 && (
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-6 text-center">
                    <p className="text-gray-600">受給者証が登録されていません</p>
                    <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                      受給者証を登録
                    </button>
                  </div>
                )}
              </div>
            ) : (
              // 一覧画面 - 4列固定表示
              <div>
                <div className="mb-4">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors flex items-center">
                    <Plus className="h-4 w-4 mr-2" />
                    受給者証を追加
                  </button>
                </div>
                
                <div className="grid grid-cols-4 gap-4">
                  {residents.map(resident => {
                    const residentCards = benefitCards.filter(card => card.residentId === resident.id);
                    const hasExpiringCard = residentCards.some(card => card.daysUntilExpiry <= 30);
                    
                    return (
                      <div 
                        key={resident.id} 
                        className={`bg-white border-2 rounded-lg p-4 hover:shadow-md transition-all cursor-pointer text-center ${
                          hasExpiringCard ? 'border-red-300 hover:border-red-400' : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedBenefitResident(resident)}
                      >
                        <div className="flex flex-col items-center">
                          <div className="h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center mb-2">
                            <User className="h-5 w-5 text-gray-400" />
                          </div>
                          <h4 className="font-medium text-gray-900 text-base">{resident.name}</h4>
                          {hasExpiringCard && (
                            <span className="mt-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              更新必要
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                {/* 統計情報 */}
                <div className="mt-6 bg-white border border-gray-200 rounded-lg p-4">
                  <h4 className="font-medium text-gray-700 mb-3">受給者証統計</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {residents.filter(resident => benefitCards.some(card => card.residentId === resident.id)).length}
                      </div>
                      <div className="text-gray-600">受給者証登録済み</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">
                        {benefitCards.filter(card => card.daysUntilExpiry <= 30).length}
                      </div>
                      <div className="text-gray-600">期限間近（30日以内）</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {benefitCards.filter(card => card.daysUntilExpiry > 30).length}
                      </div>
                      <div className="text-gray-600">期限に余裕あり</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      case 'settings':
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-6">設定</h2>
            <div className="bg-white border border-gray-200 rounded-lg p-6">
              <p className="text-gray-500">設定機能（実装予定）</p>
            </div>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  if (!currentUser) {
    return <LoginScreen />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex" style={{ fontFamily: '"Noto Sans JP", sans-serif' }}>
      <Sidebar />
      <div className="flex-1 overflow-auto">
        {renderContent()}
      </div>
    </div>
  );
};

export default App;